<?php

    $login = $_POST["login"];
    $senha = $_POST["senha"];
    include_once 'conexao.php';
    $sql = "select * from usuario where login = '".$login."' and senha = '".$senha."';";
    $query = mysqli_query($link, $sql) or die(mysqli_error($link));
    $row = mysqli_fetch_array($query);

if ($row > 0) {
    session_start();
    $_SESSION["usuario"] = $row["login"];
    $_SESSION["cod"] = $row["id"];
    echo 'Entrou';
header("Location:intranet.php");}
else{
    header("Location:index.php");
}
