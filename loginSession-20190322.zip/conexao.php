<?php

$host = "localhost";
$user = "root";
$password = "";
$database="usuario";
$link = mysqli_connect($host, $user, $password, $database);

