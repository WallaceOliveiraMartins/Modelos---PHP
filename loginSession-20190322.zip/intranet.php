<?php

session_start();
if(isset($_SESSION["usuario"])){
    echo '<h1>Olá! '. $_SESSION["usuario"].' Seja bem vindo(a)! ';
}

